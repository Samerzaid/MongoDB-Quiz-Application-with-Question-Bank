﻿using Amazon.SecurityToken.Model.Internal.MarshallTransformations;
using Labb3MongoDB.Services;
using MongoDB.Bson;
using MongoDB.Driver;

QuizRepository quiz = new QuizRepository();
quiz.QuizMenu();