﻿using DataAccess;
using MongoDB.Bson;
using MongoDB.Driver;
using System;

namespace Labb3MongoDB.Services;


public class QuizRepository
{
    private IMongoCollection<Quiz> quizCollection;
    private IMongoCollection<Question> questionCollection;


    public QuizRepository()
    {
        var hostName = "localhost";
        var port = "27017";
        var databaseName = "Labb3DB";
        var client = new MongoClient($"mongodb://{hostName}:{port}");
        var database = client.GetDatabase(databaseName);
        questionCollection =
            database.GetCollection<Question>("Questions", new MongoCollectionSettings() { AssignIdOnInsert = true });
        quizCollection =
            database.GetCollection<Quiz>("Quiz", new MongoCollectionSettings() { AssignIdOnInsert = true });
    }



    public void QuizMenu()
    {


        while (true)
        {

            Console.WriteLine("Välj ett alternativ:");
            Console.WriteLine("1. Lägga till en fråga i ett quiz");
            Console.WriteLine("2. Lägga till ett nytt quiz");
            Console.WriteLine("3. Lista frågor from ett quiz");
            Console.WriteLine("4. Lista över frågor per kategori");
            Console.WriteLine("5. Uppdatera en fråga");
            Console.WriteLine("6. Uppdatera ett quiz");
            Console.WriteLine("7. Ta bort en fråga från ett quiz");
            Console.WriteLine("8. Ta bort en fråga");
            Console.WriteLine("9. Ta bort ett quiz");
            Console.WriteLine("10. Avsluta");


            Console.Write("Välj ett alternativ: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    AddQuestionToQuiz();
                    break;
                case "2":
                    AddNewQuiz();
                    break;
                case "3":
                    ListQuestionsForQuiz();
                    break;
                case "4":
                    ListQuestionsByCategory();
                    break;
                case "5":
                    UpdateQuestion();
                    break;
                case "6":
                    UpdateQuiz();
                    break;
                case "7":
                    DeleteQuestionFromQuiz();
                    break;
                case "8":
                    DeleteQuestion();
                    break;
                case "9":
                    DeleteQuiz();
                    break;
                case "10":
                    return;
                default:
                    Console.WriteLine("Ogiltigt val, försök igen.");
                    break;
            }
        }
    }

    private void AddQuestionToQuiz()
    {
        Console.Write("Skriv frågan som du vill lägga till i ett quiz: ");
        string text = Console.ReadLine();

        List<string> options = new List<string>();
        for (int i = 1; i <= 3; i++)
        {
            Console.Write($"Ange alternativ {i}: ");
            options.Add(Console.ReadLine());
        }

        Console.Write("Skriv rätt svar: ");
        string correctAnswer = Console.ReadLine();

        Console.WriteLine("Välj kategory:");
        foreach (Category category in Enum.GetValues(typeof(Category)))
        {
            Console.WriteLine($"{(int)category}. {category}");
        }

        Console.Write("Skriv kategori index: ");
        int categoryNumber = Convert.ToInt32(Console.ReadLine());
        Category selectedCategory = (Category)categoryNumber;

        Question question = new Question
        {
            QuestionText = text,
            Options = options,
            CorrectOptionIndex = correctAnswer,
            Categories = new List<Category> { selectedCategory }
        };

        questionCollection.InsertOne(question);
        Console.WriteLine("Nu har du lagt en ny fråga.");

        var questions = questionCollection.Find(Builders<Question>.Filter.Empty).ToList();

        foreach (var _question in questions)
        {
            Console.WriteLine($"    QuestionId                | Question  | ");
            Console.WriteLine("_____________________________________________");
            Console.WriteLine($" {_question.Id} {_question.QuestionText}");
            Console.WriteLine("Alternativ:");
            foreach (var option in _question.Options)
            {
                Console.WriteLine(option);
            }

            Console.WriteLine($"Rätt svar: {question.CorrectOptionIndex}");
            Console.WriteLine($"Kategorier: {string.Join(", ", question.Categories)}");
        }

        var quizList = quizCollection.Find(Builders<Quiz>.Filter.Empty).ToList();

        foreach (var Quiz in quizList)
        {
            Console.WriteLine($"       QuizId        |  Namn    |  Beskrivning  ");
            Console.WriteLine("_____________________________________________");
            Console.WriteLine($"{Quiz.Id} {Quiz.Name}  {Quiz.Description}");

            Console.WriteLine($"Question Id: {string.Join(", ", Quiz.QuestionIds)}");
        }

        Console.Write("Skriv quiz ID: ");
        ObjectId quizId = ObjectId.Parse(Console.ReadLine());

        var quiz = quizCollection.Find(q => q.Id == quizId).FirstOrDefault();
        if (quiz == null)
        {
            Console.WriteLine("Quiz  hittades inte!");
            return;
        }

        Console.Write("Ange question Id som du vill lägga till i quizet: ");
        ObjectId questionId = ObjectId.Parse(Console.ReadLine());

        var __question = questionCollection.Find(q => q.Id == questionId).FirstOrDefault();
        if (__question == null)
        {
            Console.WriteLine("Frågan hittades inte!");
            return;
        }

        if (quiz.QuestionIds.Contains(questionId))
        {
            Console.WriteLine("Frågan har redan i quizet!");
            return;
        }

        quiz.QuestionIds.Add(questionId);
        var filter = Builders<Quiz>.Filter.Eq(q => q.Id, quizId);
        var update = Builders<Quiz>.Update.Set(q => q.QuestionIds, quiz.QuestionIds);
        quizCollection.UpdateOne(filter, update);

        Console.WriteLine("Nu har du lagt till en ny fråga i ett quiz!");
    }

    private void AddNewQuiz()
    {
        Console.Write("Ange the quiz namn: ");
        string quizName = Console.ReadLine();

        Console.Write("Skriv quiz beskrivning: ");
        string quizDescription = Console.ReadLine();

        var newQuiz = new Quiz
        {
            Name = quizName,
            Description = quizDescription,
            QuestionIds = new List<ObjectId>(),

        };

        quizCollection.InsertOne(newQuiz);

        Console.WriteLine("Nu har du gjort ett nytt quiz!");
    }
    private void ListQuestionsForQuiz()
    {
        var quizList = quizCollection.Find(Builders<Quiz>.Filter.Empty).ToList();

        foreach (var Quiz in quizList)
        {
            Console.WriteLine("=========================================================");
            Console.WriteLine("        QuizID         |   Namn    |      beskrivning |");
            Console.WriteLine("=========================================================");
            Console.WriteLine($" {Quiz.Id}     {Quiz.Name}     {Quiz.Description} ");
            Console.WriteLine("QuestionId:");
            Console.WriteLine($" - {string.Join(", ", Quiz.QuestionIds)}");
        }

        Console.Write("Ange quizId: ");
        ObjectId quizId = ObjectId.Parse(Console.ReadLine());

        var quiz = quizCollection.Find(q => q.Id == quizId).FirstOrDefault();
        if (quiz == null)
        {
            Console.WriteLine("Quiz hittades inte!");
            return;
        }

        var filter = Builders<Question>.Filter.In(q => q.Id, quiz.QuestionIds);
        var questions = questionCollection.Find(filter).ToList();

        Console.WriteLine($"Quiz: {quiz.Name}");
        Console.WriteLine("Questions:");

        foreach (var question in questions)
        {
            Console.WriteLine($"-  {question.QuestionText}");
        }
    }

    private void ListQuestionsByCategory()
    {
        foreach (Category enumDisplay in Enum.GetValues(typeof(Category)))
        {
            Console.WriteLine($" {enumDisplay}");
        }


        Console.Write("Skriv  kategori namn: ");
        string categoryName = Console.ReadLine();

        if (string.IsNullOrEmpty(categoryName))
        {
            Console.WriteLine("Kategory namn får inte vara tomt.");
            return;
        }

        if (!Enum.TryParse(typeof(Category), categoryName, true, out var categoryEnum))
        {
            Console.WriteLine("Ogiltigt kategorinamn");
            return;
        }

        var category = (Category)categoryEnum;

        var filter = Builders<Question>.Filter.Where(q => q.Categories.Contains(category));
        var questionsInCategory = questionCollection.Find(filter).ToList();

        if (questionsInCategory.Count == 0)
        {
            Console.WriteLine("Inga frågor hittades i den här kategori.");
            return;
        }

        Console.WriteLine($"Questions i categorin '{categoryName}':");
        foreach (var question in questionsInCategory)
        {
            Console.WriteLine($"- {question.QuestionText}");
            Console.WriteLine("________________________________________________");
        }

        Console.WriteLine("=====================================================");
    }

    private void UpdateQuestion()
    {

        var questions = questionCollection.Find(Builders<Question>.Filter.Empty).ToList();

        foreach (var question in questions)
        {
            Console.WriteLine($"        QuestionId     |  Question   ");
            Console.WriteLine($"  {question.Id}  {question.QuestionText}");
            Console.WriteLine("Options:");
            foreach (var option in question.Options)
            {
                Console.WriteLine(option);
            }

            Console.WriteLine($"Rätt svar: {question.CorrectOptionIndex}");
            Console.WriteLine($"Kategorier: {string.Join(", ", question.Categories)}");
            Console.WriteLine();
        }

        Console.Write("Ange the questionId som du vill updatera: ");
        ObjectId id = ObjectId.Parse(Console.ReadLine());

        var existingQuestion = questionCollection.Find(q => q.Id == id).FirstOrDefault();
        if (existingQuestion == null)
        {
            Console.WriteLine("Frågan hittades inte.");
            return;
        }

        Console.Write("Skriv den uppdaterade frågetexten: ");
        string text = Console.ReadLine();

        List<string> options = new List<string>();
        for (int i = 1; i <= 3; i++)
        {
            Console.Write($"Skriv det uppdaterade alternativet {i}: ");
            options.Add(Console.ReadLine());
        }

        Console.Write("Skriv det uppdaterade rätta svaret: ");
        string correctAnswer = Console.ReadLine();

        Console.WriteLine("Välj den uppdaterade kategorin:");
        foreach (Category category in Enum.GetValues(typeof(Category)))
        {
            Console.WriteLine($"{(int)category}. {category}");
        }

        Console.Write("Ange det uppdaterade kategori index: ");
        int categoryNumber = Convert.ToInt32(Console.ReadLine());
        Category selectedCategory = (Category)categoryNumber;

        var filter = Builders<Question>.Filter.Eq(q => q.Id, id);
        var update = Builders<Question>.Update
            .Set(q => q.QuestionText, text)
            .Set(q => q.Options, options)
            .Set(q => q.CorrectOptionIndex, correctAnswer)
            .Set(q => q.Categories, new List<Category> { selectedCategory });

        questionCollection.UpdateOne(filter, update);
        Console.WriteLine("Nu har du uppdaterat frågan.");
    }

    private void UpdateQuiz()
    {

        var quizList = quizCollection.Find(Builders<Quiz>.Filter.Empty).ToList();

        foreach (var Quiz in quizList)
        {
            Console.WriteLine($"      QuizId      |   Namn  |  Beskrivning  ");
            Console.WriteLine($"  {Quiz.Id} {Quiz.Name}  {Quiz.Description}");


            Console.WriteLine($"QuestionId: {string.Join(", ", Quiz.QuestionIds)}");
        }

        Console.Write("Enter the quiz Id to update: ");
        ObjectId id = ObjectId.Parse(Console.ReadLine());

        var existingQuiz = quizCollection.Find(q => q.Id == id).FirstOrDefault();
        if (existingQuiz == null)
        {
            Console.WriteLine("Quizet hittades inte.");
            return;
        }

        Console.Write("Skriv det uppdaterade Quiz namnet: ");
        string title = Console.ReadLine();


        Console.Write("Skriv den uppdaterade beskrivning: ");
        string description = Console.ReadLine();


        var filter = Builders<Quiz>.Filter.Eq(q => q.Id, id);
        var update = Builders<Quiz>.Update
            .Set(q => q.Name, title)
            .Set(q => q.Description, description);


        quizCollection.UpdateOne(filter, update);
        Console.WriteLine("Nu har du uppdaterat quizet.");

    }

    private void DeleteQuestionFromQuiz()
    {
        var quizList = quizCollection.Find(Builders<Quiz>.Filter.Empty).ToList();

        foreach (var Quiz in quizList)
        {
            Console.WriteLine($"     QuizId     |  Namn  | Beskrivning  ");
            Console.WriteLine($" {Quiz.Id}  {Quiz.Name}  {Quiz.Description}");

            Console.WriteLine($"Question Id: {string.Join(", ", Quiz.QuestionIds)}");
        }

        Console.Write("Ange quiz ID: ");
        ObjectId quizId = ObjectId.Parse(Console.ReadLine());

        var quiz = quizCollection.Find(q => q.Id == quizId).FirstOrDefault();
        if (quiz == null)
        {
            Console.WriteLine("Quiz hittades inte!");
            return;
        }

        var questions = questionCollection.Find(Builders<Question>.Filter.Empty).ToList();

        foreach (var question in questions)
        {
            Console.WriteLine($"Id: {question.Id}");
            Console.WriteLine($"Question: {question.QuestionText}");
        }

        Console.Write("Ange question ID som du vill ta bort från quizet: ");
        ObjectId questionId = ObjectId.Parse(Console.ReadLine());

        if (!quiz.QuestionIds.Contains(questionId))
        {
            Console.WriteLine("Frågan hittades inte i quizet!");
            return;
        }

        quiz.QuestionIds.Remove(questionId);
        var filter = Builders<Quiz>.Filter.Eq(q => q.Id, quizId);
        var update = Builders<Quiz>.Update.Set(q => q.QuestionIds, quiz.QuestionIds);
        quizCollection.UpdateOne(filter, update);

        Console.WriteLine("Nu har du tagit bort frågan från quizet!");
    }


    private void DeleteQuestion()
    {
        var questions = questionCollection.Find(Builders<Question>.Filter.Empty).ToList();

        foreach (var question in questions)
        {
            Console.WriteLine($"      QuestionId    | Question  ");
            Console.WriteLine("_________________________________________________");
            Console.WriteLine($" {question.Id}  {question.QuestionText}");
            Console.WriteLine("Options:");
            foreach (var option in question.Options)
            {
                Console.WriteLine(option);
            }

            Console.WriteLine($"Rätt svar: {question.CorrectOptionIndex}");
            Console.WriteLine($"Kategorier: {string.Join(", ", question.Categories)}");
        }

        Console.Write("Ange questionId som du ta bort: ");
        ObjectId id = ObjectId.Parse(Console.ReadLine());


        var filter = Builders<Question>.Filter.Eq(q => q.Id, id);
        var result = questionCollection.DeleteOne(filter);

        if (result.DeletedCount > 0)
        {
            Console.WriteLine("Nu har du tagit bort frågan.");
        }
        else
        {
            Console.WriteLine("Frågan hittades inte.");
        }
    }

    private void DeleteQuiz()
    {
        var quizList = quizCollection.Find(Builders<Quiz>.Filter.Empty).ToList();

        foreach (var Quiz in quizList)
        {
            Console.WriteLine($"     QuizId           |  Namn   |  Beskrivning ");
            Console.WriteLine("__________________________________________________");
            Console.WriteLine($" {Quiz.Id}     {Quiz.Name}   {Quiz.Description}");

            Console.WriteLine($"Question Id: {string.Join(", ", Quiz.QuestionIds)}");
        }

        Console.Write("Ange QuizId som du vill ta bort: ");
        ObjectId id = ObjectId.Parse(Console.ReadLine());


        var filter = Builders<Quiz>.Filter.Eq(q => q.Id, id);
        var result = quizCollection.DeleteOne(filter);

        if (result.DeletedCount > 0)
        {
            Console.WriteLine("Nu har du tagit bort quizet.");
        }
        else
        {
            Console.WriteLine("Quizet hittades inte.");
        }
    }

}

