﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;

namespace DataAccess;

public class Quiz
{
    [BsonId]
    public ObjectId Id { get; set; }

    public string Name { get; set; }
    public string Description { get; set; }
    public List<ObjectId> QuestionIds { get; set; }
}