﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace DataAccess;

public class Question
{
    [BsonId]

    public ObjectId Id { get; set; }
    public string QuestionText { get; set; }
    public List<string> Options { get; set; }
    public string CorrectOptionIndex { get; set; }
    public List<Category> Categories { get; set; }
}