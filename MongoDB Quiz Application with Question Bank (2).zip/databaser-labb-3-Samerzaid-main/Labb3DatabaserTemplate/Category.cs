﻿namespace DataAccess;

public enum Category
{
    English,
    Math,
    Programming,
    Sport
}